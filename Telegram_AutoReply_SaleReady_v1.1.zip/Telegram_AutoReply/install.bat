@echo off
chcp 65001 >nul
setlocal
title Telegram AutoReply - Installation
cd /d "%~dp0"

echo ========================================
echo   Telegram AutoReply - Installation
echo ========================================
echo.

where py >nul 2>&1
if %errorlevel%==0 (
    set "PY=py"
) else (
    where python >nul 2>&1
    if %errorlevel%==0 (
        set "PY=python"
    ) else (
        echo [ERROR] Python was not found.
        echo Install Python 3.10+ and enable "Add Python to PATH".
        pause
        exit /b 1
    )
)

%PY% -m pip install --upgrade pip
if errorlevel 1 (
    echo [ERROR] Failed to update pip.
    pause
    exit /b 1
)

%PY% -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Failed to install dependencies.
    pause
    exit /b 1
)

echo.
echo [OK] Installation completed.
echo You can now run start.bat
pause
