import asyncio
import json
import os
from datetime import datetime, timezone

from telethon import TelegramClient, events
from dotenv import load_dotenv

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))

CONFIG_FILE = os.path.join(BASE_DIR, "config.json")


def load_config():
    default = {
        "auto_reply": "Привет! Я сейчас занят и отвечу позже.",
        "enabled": True,
        "reply_once_minutes": 30,
        "only_private_messages": True,
        "ignore_groups": True,
        "ignore_users": [],
        "only_users": [],
        "keywords": [],
        "keyword_mode": "contains"
    }

    if not os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(default, f, ensure_ascii=False, indent=4)
        return default

    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError("config.json должен содержать JSON-объект")
        default.update(data)
        return default
    except (OSError, json.JSONDecodeError, ValueError) as e:
        print(f"[!] Ошибка чтения config.json: {e}")
        print("[!] Будут использованы настройки по умолчанию.")
        return default


def save_config(config):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=4)


def get_required_env(name):
    value = os.getenv(name, "").strip()
    if not value:
        print(f"[!] Не указан {name} в файле .env")
        return None
    return value


async def main():
    api_id_raw = get_required_env("TG_API_ID")
    api_hash = get_required_env("TG_API_HASH")

    if not api_id_raw or not api_hash:
        print("\nОткрой .env и укажи TG_API_ID и TG_API_HASH.")
        print("Получить их можно на https://my.telegram.org/apps")
        input("\nНажми Enter для выхода...")
        return

    try:
        api_id = int(api_id_raw)
    except ValueError:
        print("[!] TG_API_ID должен быть числом.")
        input("Нажми Enter для выхода...")
        return

    config = load_config()
    session_path = os.path.join(BASE_DIR, "telegram_autoreply")

    client = TelegramClient(session_path, api_id, api_hash)
    last_replied = {}

    print("=" * 60)
    print(" Telegram AutoReply")
    print("=" * 60)
    print(f"Статус автоответа: {'ВКЛ' if config['enabled'] else 'ВЫКЛ'}")
    print(f"Cooldown: {config['reply_once_minutes']} мин.")
    print("Подключение к Telegram...\n")

    try:
        await client.start()
    except Exception as e:
        print(f"[!] Ошибка подключения: {e}")
        input("Нажми Enter для выхода...")
        return

    me = await client.get_me()
    username = f"@{me.username}" if me.username else me.first_name or "аккаунт"

    print(f"[+] Авторизован: {username}")
    print("[+] AutoReply запущен.")
    print("[+] Для остановки нажми Ctrl+C.\n")

    @client.on(events.NewMessage(incoming=True))
    async def handler(event):
        if not config.get("enabled", True):
            return

        # Автоответчик предназначен для личных входящих сообщений.
        if config.get("only_private_messages", True) and not event.is_private:
            return

        if event.out:
            return

        sender = await event.get_sender()
        if not sender:
            return

        sender_id = sender.id
        username_sender = (getattr(sender, "username", None) or "").lower()

        ignored = {str(x).lower().lstrip("@") for x in config.get("ignore_users", [])}
        allowed = {str(x).lower().lstrip("@") for x in config.get("only_users", [])}

        if str(sender_id) in ignored or username_sender in ignored:
            return

        if allowed and str(sender_id) not in allowed and username_sender not in allowed:
            return

        text = event.raw_text or ""
        keywords = [str(x).lower() for x in config.get("keywords", [])]

        if keywords:
            haystack = text.lower()
            if config.get("keyword_mode") == "exact":
                if not any(haystack.strip() == word for word in keywords):
                    return
            else:
                if not any(word in haystack for word in keywords):
                    return

        cooldown = max(0, int(config.get("reply_once_minutes", 30)))
        now = datetime.now(timezone.utc)

        if sender_id in last_replied:
            elapsed = (now - last_replied[sender_id]).total_seconds()
            if elapsed < cooldown * 60:
                return

        message = str(config.get("auto_reply", "")).strip()
        if not message:
            return

        try:
            await event.respond(message)
            last_replied[sender_id] = now
            name = getattr(sender, "first_name", None) or username_sender or str(sender_id)
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Ответ отправлен: {name}")
        except Exception as e:
            print(f"[!] Не удалось отправить ответ: {e}")

    try:
        await client.run_until_disconnected()
    except KeyboardInterrupt:
        print("\n[+] AutoReply остановлен.")
    finally:
        await client.disconnect()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nAutoReply остановлен.")
