@echo off
chcp 65001 >nul
setlocal
title Telegram AutoReply
cd /d "%~dp0"

where py >nul 2>&1
if %errorlevel%==0 (
    set "PY=py"
) else (
    where python >nul 2>&1
    if %errorlevel%==0 (
        set "PY=python"
    ) else (
        echo [ERROR] Python was not found.
        echo Run install.bat after installing Python 3.10+.
        pause
        exit /b 1
    )
)

%PY% main.py
if errorlevel 1 (
    echo.
    echo [ERROR] The program exited with an error.
)
pause
